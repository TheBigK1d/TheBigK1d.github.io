    </div><!-- #main -->
 
    <div id="footer">
        <div id="colophon">
 
            <div id="site-info">


			<p>	Created with: Wordpress,
			<a href="https://github.com/VincentGarreau/particles.js/">particle.js</a>
			and <a href="https://bootswatch.com/darkly/">darkly.css</a>  </p>

            <p>	John Compas 2016 </p>

            </div><!-- #site-info -->
 
        </div><!-- #colophon -->
    </div><!-- #footer -->
</div><!-- #wrapper -->
<?php wp_footer(); ?>
</body>
</html>